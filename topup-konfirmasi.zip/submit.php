<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $username = htmlspecialchars($_POST['username']);
  $nominal = htmlspecialchars($_POST['nominal']);
  $metode = htmlspecialchars($_POST['metode']);

  $uploadDir = 'uploads/';
  if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
  }

  $fileName = basename($_FILES['bukti']['name']);
  $uploadPath = $uploadDir . time() . "_" . $fileName;

  if (move_uploaded_file($_FILES['bukti']['tmp_name'], $uploadPath)) {
    echo "<h2>Konfirmasi Berhasil!</h2>";
    echo "<p>Username: $username</p>";
    echo "<p>Nominal: Rp " . number_format($nominal, 0, ',', '.') . "</p>";
    echo "<p>Metode Pembayaran: $metode</p>";
    echo "<p>Bukti Transfer: <br><img src='$uploadPath' width='200'></p>";
  } else {
    echo "<p style='color:red;'>Upload bukti transfer gagal.</p>";
  }
}
?>