document.getElementById("topupForm").addEventListener("submit", function(e) {
  const fileInput = document.querySelector('input[name="bukti"]');
  if (fileInput.files.length === 0) {
    alert("Mohon upload bukti transfer!");
    e.preventDefault();
  }
});